<?php
/*
 * Plugin Name:       Social Share FLYmotion
 * Plugin URI:        https://www.flymotion.my.id/plugins/
 * Description:       Social share buttons plugin with Google Analytics tracking, automatic description from article content, and featured image.
 * Version:           1.1.1
 * Author:            FLYMotion
 * Author URI:        https://instagram.com/amaryourbae
 * License:           GPLv3
 * License URI:       http://www.gnu.org/licenses/gpl.html
 * Text Domain:       flymotion
 * Domain Path:       /lang
 */

defined('ABSPATH') || exit;

// Register Elementor widget
add_action('elementor/widgets/register', function($widgets_manager) {
    if (defined('ELEMENTOR_VERSION')) {
        require_once(__DIR__ . '/widgets/social-share-widget.php');
        $widgets_manager->register(new \Elementor\Social_Share_Widget());
    }
});

// Tambah submenu untuk dashboard analytics
add_action('admin_menu', function () {
    add_submenu_page(
        'tools.php',
        'Social Share Analytics',
        'Social Share Analytics',
        'manage_options',
        'social-share-analytics',
        'render_social_share_analytics_page'
    );
});

function render_social_share_analytics_page() {
    $platforms = ['facebook', 'twitter', 'linkedin', 'whatsapp', 'telegram', 'email'];

    $start_date = isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : '';
    $end_date = isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : '';

    $args = [
        'post_type' => 'post',
        'posts_per_page' => -1,
        'post_status' => 'publish',
    ];

    if ($start_date || $end_date) {
        $args['date_query'] = [];
        if ($start_date) $args['date_query'][] = ['after' => $start_date];
        if ($end_date) $args['date_query'][] = ['before' => $end_date];
        $args['date_query']['inclusive'] = true;
    }

    $posts = get_posts($args);

    echo '<div class="wrap"><h1>Social Share Analytics</h1>';

    $platform_totals = array_fill_keys($platforms, 0);
    foreach ($posts as $post) {
        foreach ($platforms as $platform) {
            $platform_totals[$platform] += (int) get_post_meta($post->ID, '_social_share_' . $platform, true);
        }
    }

    echo '<h2>Platform Share Chart</h2>';
    echo '<canvas id="socialShareChart" width="600" height="200"></canvas>';
    echo '<script>
    document.addEventListener("DOMContentLoaded", function () {
        const ctx = document.getElementById("socialShareChart").getContext("2d");
        const chart = new Chart(ctx, {
            type: "bar",
            data: {
                labels: ' . json_encode(array_map('ucfirst', array_keys($platform_totals))) . ',
                datasets: [{
                    label: "Total Shares",
                    data: ' . json_encode(array_values($platform_totals)) . ',
                    backgroundColor: "rgba(54, 162, 235, 0.6)",
                    borderColor: "rgba(54, 162, 235, 1)",
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false },
                    tooltip: { enabled: true }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { precision: 0 }
                    }
                }
            }
        });
    });
    </script>';

    echo '<form method="get">';
    echo '<input type="hidden" name="page" value="social-share-analytics">';
    echo '<label>Start Date: <input type="date" name="start_date" value="' . esc_attr($start_date) . '"></label> ';
    echo '<label>End Date: <input type="date" name="end_date" value="' . esc_attr($end_date) . '"></label> ';
    echo '<button type="submit" class="button button-primary">Filter</button> ';
    echo '<a href="' . admin_url('tools.php?page=social-share-analytics') . '" class="button">Reset</a>';
    echo '</form><br>';

    echo '<form method="post">';
    echo '<input type="hidden" name="export_csv" value="1">';
    echo '<input type="hidden" name="start_date" value="' . esc_attr($start_date) . '">';
    echo '<input type="hidden" name="end_date" value="' . esc_attr($end_date) . '">';
    echo '<button type="submit" class="button">Export CSV</button>';
    echo '</form><br>';

    echo '<table class="widefat fixed striped">';
    echo '<thead><tr><th>Title</th>';
    foreach ($platforms as $platform) {
        echo '<th>' . ucfirst($platform) . '</th>';
    }
    echo '<th>Total</th></tr></thead><tbody>';

    foreach ($posts as $post) {
        echo '<tr>';
        echo '<td><a href="' . get_edit_post_link($post->ID) . '">' . esc_html($post->post_title) . '</a></td>';

        $total = 0;
        foreach ($platforms as $platform) {
            $count = (int) get_post_meta($post->ID, '_social_share_' . $platform, true);
            $total += $count;
            echo '<td>' . $count . '</td>';
        }

        echo '<td><strong>' . $total . '</strong></td>';
        echo '</tr>';
    }

    echo '</tbody></table></div>';
}

add_action('admin_init', function () {
    if (isset($_POST['export_csv']) && current_user_can('manage_options')) {
        $platforms = ['facebook', 'twitter', 'linkedin', 'whatsapp', 'telegram', 'email'];

        $start_date = sanitize_text_field($_POST['start_date'] ?? '');
        $end_date = sanitize_text_field($_POST['end_date'] ?? '');

        $args = [
            'post_type' => 'post',
            'posts_per_page' => -1,
            'post_status' => 'publish',
        ];

        if ($start_date || $end_date) {
            $args['date_query'] = [];
            if ($start_date) $args['date_query'][] = ['after' => $start_date];
            if ($end_date) $args['date_query'][] = ['before' => $end_date];
            $args['date_query']['inclusive'] = true;
        }

        $posts = get_posts($args);

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="social-share-analytics.csv"');
        $output = fopen('php://output', 'w');

        fputcsv($output, array_merge(['Title'], array_map('ucfirst', $platforms), ['Total']));

        foreach ($posts as $post) {
            $row = [get_the_title($post)];
            $total = 0;
            foreach ($platforms as $platform) {
                $count = (int) get_post_meta($post->ID, '_social_share_' . $platform, true);
                $total += $count;
                $row[] = $count;
            }
            $row[] = $total;
            fputcsv($output, $row);
        }

        fclose($output);
        exit;
    }
});

add_action('admin_enqueue_scripts', function($hook) {
    if ($hook === 'tools_page_social-share-analytics') {
        wp_enqueue_script('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js', [], null, true);
    }
});

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('social-share-flymotion', plugin_dir_url(__FILE__) . 'assets/css/social-share.min.css');
    wp_enqueue_script('social-share-flymotion', plugin_dir_url(__FILE__) . 'assets/js/social-share.js', [], false, true);

    wp_localize_script('social-share-flymotion', 'SocialShareFlymotion', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('social_share_nonce')
    ]);

    $icon_base_url = plugin_dir_url(__FILE__) . 'assets/icons/social-media/';
    $custom_css = "
        .icon-facebook::before { background-image: url('{$icon_base_url}facebook-logo.svg'); }
        .icon-twitter::before { background-image: url('{$icon_base_url}twitter-logo.svg'); }
        .icon-linkedin::before { background-image: url('{$icon_base_url}linkedin-logo.svg'); }
        .icon-whatsapp::before { background-image: url('{$icon_base_url}whatsapp-logo.svg'); }
        .icon-telegram::before { background-image: url('{$icon_base_url}telegram-logo.svg'); }
        .icon-custom::before { background-image: url('{$icon_base_url}share-logo.svg'); }
        .icon-email::before { background-image: url('{$icon_base_url}email-logo.svg'); }
    ";
    wp_add_inline_style('social-share-flymotion', $custom_css);
});

add_action('wp_head', function() {
    if (is_single()) {
        global $post;
        $image = get_the_post_thumbnail_url($post, 'full');
        $title = get_the_title($post);
        $excerpt = wp_strip_all_tags($post->post_excerpt ?: wp_trim_words($post->post_content, 15));
        $url = get_permalink($post);

        echo '<meta property="og:title" content="' . esc_attr($title) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr($excerpt) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
        echo '<meta property="og:image" content="' . esc_url($image) . '">' . "\n";
        echo '<meta property="og:type" content="article">' . "\n";
    }
});
