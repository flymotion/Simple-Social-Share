<?php
defined('ABSPATH') || exit;

if (!function_exists('get_plugin_data')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

$main_plugin_file = __DIR__ . '/../social-share-flymotion.php';

$expected = [
    'Name'       => 'Social Share FLYmotion',
    'PluginURI'  => 'https://www.flymotion.my.id/plugins/',
    'Author'     => 'FLYMotion',
    'AuthorURI'  => 'https://instagram.com/amaryourbae',
];

$expected_hash = '5dd79726014524cf2b8d35e02cc1e212439087d06c4223645bf5e1522b2d8594';
$plugin_data = get_plugin_data($main_plugin_file);

foreach ($expected as $key => $value) {
    if (!isset($plugin_data[$key]) || trim($plugin_data[$key]) !== $value) {
        deactivate_plugins(plugin_basename($main_plugin_file));
        wp_die("Plugin telah dimodifikasi secara tidak sah (metadata tidak cocok).", 'Plugin Dinonaktifkan', ['back_link' => true]);
    }
}

$current_hash = hash_file('sha256', $main_plugin_file);
if ($current_hash !== $expected_hash) {
    deactivate_plugins(plugin_basename($main_plugin_file));
    wp_die("Plugin telah dimodifikasi secara tidak sah (checksum gagal).", 'Plugin Dinonaktifkan', ['back_link' => true]);
}
