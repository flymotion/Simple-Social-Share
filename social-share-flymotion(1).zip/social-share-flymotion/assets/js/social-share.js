document.addEventListener('DOMContentLoaded', () => {
  const buttons = document.querySelectorAll('.social-share-button[data-platform]');

  buttons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const platform = btn.dataset.platform;
      const title = btn.dataset.title || document.title;
      const url = btn.dataset.url || window.location.href;
      const excerpt = btn.dataset.excerpt || '';
      const postId = btn.dataset.postId;

      const fullText = `${title}\n\n${url}\n\n${excerpt}`;
      let shareUrl = '';

      switch (platform) {
        case 'facebook':
          shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
          break;
        case 'twitter':
          shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(fullText)}`;
          break;
        case 'linkedin':
          shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
          break;
        case 'whatsapp':
          shareUrl = `https://wa.me/?text=${encodeURIComponent(fullText)}`;
          break;
        case 'telegram':
          shareUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(fullText)}`;
          break;
        case 'email':
          shareUrl = `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(fullText)}`;
          btn.setAttribute('href', shareUrl);
          return;
        default:
          return;
      }

      e.preventDefault();
      window.open(shareUrl, '_blank', 'width=600,height=500');

      // Google Analytics tracking
      if (typeof gtag === 'function') {
        gtag('event', 'click', {
          event_category: 'Social Share',
          event_label: platform
        });
      }

      // Spinner display
      const spinner = btn.querySelector('.share-spinner');
      if (spinner) spinner.style.display = 'inline-block';

      // AJAX request
      if (typeof SocialShareFlymotion !== 'undefined') {
        fetch(SocialShareFlymotion.ajax_url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: new URLSearchParams({
            action: 'record_social_share',
            post_id: postId,
            platform: platform,
            _ajax_nonce: SocialShareFlymotion.nonce
          })
        })
        .then(res => res.json())
        .then(data => {
          const countElem = btn.querySelector('.share-count');
          if (data.success && countElem) {
            countElem.textContent = data.data.new_count;
          }
        })
        .catch(console.error)
        .finally(() => {
          if (spinner) spinner.style.display = 'none';
        });
      }
    });
  });
});
