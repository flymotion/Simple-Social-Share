<?php
namespace Elementor;

if (!defined('ABSPATH')) exit;

class Social_Share_Widget extends Widget_Base {
    public function get_name() {
        return 'social_share_flymotion';
    }

    public function get_title() {
        return __('Social Share Flymotion', 'social-share-flymotion');
    }

    public function get_icon() {
        return 'eicon-share';
    }

    public function get_categories() {
        return ['general'];
    }

    public function _register_controls() {
        $this->start_controls_section('content_section', [
            'label' => __('Share Settings', 'social-share-flymotion'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('share_platforms', [
            'label' => __('Platforms', 'social-share-flymotion'),
            'type' => Controls_Manager::SELECT2,
            'multiple' => true,
            'options' => [
                'facebook' => 'Facebook',
                'twitter' => 'Twitter',
                'linkedin' => 'LinkedIn',
                'whatsapp' => 'WhatsApp',
                'telegram' => 'Telegram',
                'email' => 'Email'
            ],
            'default' => ['facebook', 'twitter'],
        ]);

        $this->add_control('custom_platform_name', [
            'label' => __('Custom Platform Name', 'social-share-flymotion'),
            'type' => Controls_Manager::TEXT,
            'placeholder' => 'e.g., Reddit',
        ]);

        $this->add_control('custom_platform_url', [
            'label' => __('Custom Share URL (use {url}, {title}, {excerpt})', 'social-share-flymotion'),
            'type' => Controls_Manager::TEXT,
            'placeholder' => 'https://www.reddit.com/submit?url={url}&title={title}',
        ]);

        $this->add_control('floating', [
            'label' => __('Enable Floating Bar', 'social-share-flymotion'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'no',
        ]);

        $this->add_control('icon_vertical_layout', [
            'label' => __('Icon + Label Vertikal', 'social-share-flymotion'),
            'type' => Controls_Manager::SWITCHER,
            'description' => __('Tampilkan label platform di bawah ikon.'),
            'default' => 'yes',
        ]);

        $this->add_control('show_share_counts', [
            'label' => __('Show Share Counts', 'social-share-flymotion'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes',
        ]);

        $this->add_control('enable_ga_tracking', [
            'label' => __('Enable Google Analytics Click Tracking', 'social-share-flymotion'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'no',
        ]);

        $this->end_controls_section();

        $this->start_controls_section('style_section', [
            'label' => __('Style', 'social-share-flymotion'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_responsive_control('icon_size', [
            'label' => __('Icon Size (px)', 'social-share-flymotion'),
            'type' => Controls_Manager::SLIDER,
            'range' => [ 'px' => ['min' => 16, 'max' => 128] ],
            'default' => ['size' => 32],
            'selectors' => [
                '{{WRAPPER}} .social-share-button span[class^="icon-"]::before' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('label_font_size', [
            'label' => __('Label Font Size', 'social-share-flymotion'),
            'type' => Controls_Manager::SLIDER,
            'range' => [ 'px' => ['min' => 8, 'max' => 24] ],
            'default' => ['size' => 12],
            'selectors' => [
                '{{WRAPPER}} .social-share-button .platform-label' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('icon_spacing', [
            'label' => __('Spacing Antar Ikon', 'social-share-flymotion'),
            'type' => Controls_Manager::SLIDER,
            'range' => [ 'px' => ['min' => 0, 'max' => 100] ],
            'default' => ['size' => 4],
            'selectors' => [
                '{{WRAPPER}} .social-share-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('button_padding', [
            'label' => __('Padding Tombol Share', 'social-share-flymotion'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'default' => [ 'top' => 8, 'right' => 8, 'bottom' => 8, 'left' => 8, 'unit' => 'px' ],
            'selectors' => [
                '{{WRAPPER}} .social-share-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('button_margin', [
            'label' => __('Margin Tombol Share', 'social-share-flymotion'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .social-share-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('alignment', [
            'label' => __('Alignment', 'social-share-flymotion'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'flex-start' => [ 'title' => __('Kiri', 'social-share-flymotion'), 'icon' => 'eicon-h-align-left' ],
                'center' => [ 'title' => __('Tengah', 'social-share-flymotion'), 'icon' => 'eicon-h-align-center' ],
                'flex-end' => [ 'title' => __('Kanan', 'social-share-flymotion'), 'icon' => 'eicon-h-align-right' ],
                'space-between' => [ 'title' => __('Rata', 'social-share-flymotion'), 'icon' => 'eicon-h-align-stretch' ],
            ],
            'default' => 'flex-start',
            'selectors' => [
                '{{WRAPPER}} .social-share-wrapper' => 'justify-content: {{VALUE}};',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $platforms = $settings['share_platforms'];
        $floating_class = $settings['floating'] === 'yes' ? ' floating' : '';
        $show_counts = $settings['show_share_counts'] === 'yes';
        $post_id = get_the_ID();
        $post_title = get_the_title();
        $post_url = get_permalink();
        $post_excerpt = urldecode($this->get_share_excerpt());

        echo '<div class="social-share-wrapper' . esc_attr($floating_class) . '">';

        $vertical_layout = $settings['icon_vertical_layout'] === 'yes';
        $button_class = 'social-share-button' . ($vertical_layout ? ' vertical' : '');

        foreach ($platforms as $platform) {
            $share_url = $this->get_share_url($platform);
            $platform_count = (int) get_post_meta($post_id, '_social_share_' . $platform, true);

            echo '<a href="' . esc_url($share_url) . '" 
                class="' . esc_attr($button_class) . '" 
                target="_blank" 
                rel="noopener noreferrer"
                data-platform="' . esc_attr($platform) . '"
                data-title="' . esc_attr($post_title) . '"
                data-url="' . esc_url($post_url) . '"
                data-excerpt="' . esc_attr($post_excerpt) . '"
                data-post-id="' . esc_attr($post_id) . '">';

            echo '<div class="icon-label-wrap">';
            echo '<span class="icon-' . esc_attr($platform) . '"></span>';
            echo '<span class="platform-label">' . ucfirst($platform) . '</span>';
            echo '</div>';

            if ($show_counts) {
                echo '<span class="share-count">' . $platform_count . '</span>';
            }

            echo '</a>';
        }

        if (!empty($settings['custom_platform_name']) && !empty($settings['custom_platform_url'])) {
            $custom_url = str_replace(
                ['{url}', '{title}', '{excerpt}'],
                [urlencode($post_url), urlencode($post_title), urlencode($post_excerpt)],
                $settings['custom_platform_url']
            );

            echo '<a href="' . esc_url($custom_url) . '" 
                class="' . esc_attr($button_class) . '" 
                target="_blank" 
                rel="noopener noreferrer"
                data-platform="custom-' . esc_attr($settings['custom_platform_name']) . '"
                data-title="' . esc_attr($post_title) . '"
                data-url="' . esc_url($post_url) . '"
                data-excerpt="' . esc_attr($post_excerpt) . '"
                data-post-id="' . esc_attr($post_id) . '">';

            echo '<div class="icon-label-wrap">';
            echo '<span class="icon-custom"></span>';
            echo '<span class="platform-label">' . esc_html($settings['custom_platform_name']) . '</span>';
            echo '</div>';

            if ($show_counts) {
                echo '<span class="share-count">0</span>';
            }

            echo '</a>';
        }

        if ($show_counts) {
            $total = 0;
            foreach ($platforms as $platform) {
                $total += (int) get_post_meta($post_id, '_social_share_' . $platform, true);
            }
            echo '<div class="total-share">Total: <span class="total-share-count">' . $total . '</span></div>';
        }

        echo '</div>';
    }

    private function get_share_url($platform) {
        $post_url = urlencode(get_permalink());
        $post_title = urlencode(get_the_title());
        $post_excerpt = $this->get_share_excerpt();

        switch ($platform) {
            case 'facebook': return "https://www.facebook.com/sharer/sharer.php?u=$post_url";
            case 'twitter': return "https://twitter.com/intent/tweet?text=$post_title&url=$post_url";
            case 'linkedin': return "https://www.linkedin.com/sharing/share-offsite/?url=$post_url";
            case 'whatsapp': return "https://wa.me/?text=$post_title%0A%0A$post_url%0A%0A$post_excerpt";
            case 'telegram': return "https://t.me/share/url?url=$post_url&text=$post_excerpt";
            case 'email': return "mailto:?subject=$post_title&body=$post_title%0A%0A$post_url%0A%0A$post_excerpt";
            default: return '#';
        }
    }

    private function get_share_excerpt() {
        $content = get_post_field('post_content', get_the_ID());
        $content = wp_strip_all_tags($content);
        $paragraphs = preg_split('/\n+/', trim($content));
        $first_paragraph = isset($paragraphs[0]) ? $paragraphs[0] : substr($content, 0, 100);
        $words = explode(' ', $first_paragraph);
        $excerpt = implode(' ', array_slice($words, 0, 15));
        return urlencode($excerpt);
    }
}

add_action('wp_ajax_record_social_share', 'record_social_share_callback');
add_action('wp_ajax_nopriv_record_social_share', 'record_social_share_callback');

function record_social_share_callback() {
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    $platform = sanitize_text_field($_POST['platform'] ?? '');

    if ($post_id && $platform) {
        $meta_key = '_social_share_' . $platform;
        $current = (int) get_post_meta($post_id, $meta_key, true);
        update_post_meta($post_id, $meta_key, $current + 1);
        wp_send_json_success(['new_count' => $current + 1]);
    }

    wp_send_json_error();
}
